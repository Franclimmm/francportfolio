from django.contrib import admin
from .models import Service, Stylist, Appointment

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'duration')
    search_fields = ('name',)

@admin.register(Stylist)
class StylistAdmin(admin.ModelAdmin):
    list_display = ('name', 'specialties')
    search_fields = ('name', 'specialties')

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('customer_name', 'date', 'time', 'service', 'stylist')
    list_filter = ('date', 'service', 'stylist')
    search_fields = ('customer_name', 'email', 'phone')
