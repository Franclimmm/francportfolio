from django.shortcuts import render

from .forms import AppointmentForm
from .models import Service


def home(request):
    services = Service.objects.all()
    return render(request, 'home.html', {'services': services})

def services(request):
    services = Service.objects.all()
    return render(request, 'services.html', {'services': services})

def booking(request):
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'booking_success.html')
    else:
        form = AppointmentForm()
    return render(request, 'booking.html', {'form': form})

def contact(request):
    return render(request, 'contact.html')
